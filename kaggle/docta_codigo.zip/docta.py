#!/usr/bin/env python3
"""
Docta — punto de entrada.

Uso:
    python docta.py                    conversación interactiva
    python docta.py -p "tu pregunta"   una sola pregunta
    python docta.py --quien            quién es y qué sabe
    python docta.py --tripa            enseña las puntuaciones internas

Comandos dentro de la conversación:
    /quien     presentación
    /temas     qué materias tiene curadas
    /limite    hasta cuándo sabe cosas
    /salir

De momento responde DIRECTAMENTE desde la base curada, sin pasar por la red
neuronal. No es una solución provisional por pereza: con un modelo de 7M
parámetros entrenado sobre 2.000 tokens, dejarle reescribir un dato correcto
solo puede empeorarlo. La red entra cuando haya corpus suficiente para que
aportar algo sea más probable que estropearlo. Lo que sí está ya funcionando es
la pieza difícil, que es decidir cuándo callarse.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from identidad import NOMBRE, construir_identidad            # noqa: E402
from knowledge import BaseConocimiento                       # noqa: E402
from retriever import Retriever, formular_ignorancia          # noqa: E402

MARCA = {
    "seguro": "  ",
    "probable": "~ ",
    "dudoso": "? ",
    "no_lo_se": "· ",
}


class Docta:
    """Fachada: junta identidad, base de conocimiento y puerta de ignorancia."""

    def __init__(self, umbral_apoyo: float = 0.15):
        self.base = BaseConocimiento.cargar()
        self.idn = construir_identidad(self.base)
        self.busca = Retriever(self.base, umbral_apoyo=umbral_apoyo)
        self.turnos = 0

    # ------------------------------------------------------------------ #
    def responder(self, pregunta: str, tripa: bool = False) -> str:
        """
        El camino completo: recuperar -> puerta de ignorancia -> tono.

        Devuelve texto plano. La decisión de SABER o NO SABER se toma antes de
        generar una sola palabra, que es el orden correcto: si se decide
        después, el sistema ya se ha enamorado de su propia respuesta.
        """
        pregunta = pregunta.strip()
        if not pregunta:
            return ""

        r = self.busca.consultar(pregunta)
        self.turnos += 1

        if not r.sabe:
            salida = formular_ignorancia(r)
        else:
            salida = self.idn.respuesta_sin_modelo(r.grado, r.mejor.hecho.respuesta)

        if tripa:
            salida += self._diagnostico(r)
        return salida

    def _diagnostico(self, r) -> str:
        """Lo que hay debajo: útil para ajustar umbrales sin adivinar."""
        lineas = [
            "",
            f"  ┌ grado={r.grado}  apoyo={r.apoyo:.3f}  "
            f"rechazo={r.motivo_rechazo or '—'}",
        ]
        for c in r.candidatos[:3]:
            lineas.append(
                f"  │ {c.hecho.id:16} sim={c.similitud:.3f} "
                f"certeza={c.hecho.certeza:.2f} {' '.join(c.motivos)}")
        if not r.candidatos:
            lineas.append("  │ (ningún candidato por encima de cero)")
        lineas.append("  └")
        return "\n".join(lineas)

    # ------------------------------------------------------------------ #
    def quien(self) -> str:
        return self.idn.presentacion()

    def temas(self) -> str:
        stats = self.base.estadisticas()
        lineas = [f"{self.idn.total_hechos} hechos curados, en:"]
        por_tema: dict[str, int] = {}
        for h in self.base:
            if h.nivel != "meta":
                por_tema[h.tema] = por_tema.get(h.tema, 0) + 1
        for tema in sorted(por_tema):
            lineas.append(f"  {tema:34} {por_tema[tema]:>3}")
        lineas.append(f"\nCerteza media de los datos: {stats['certeza_media']}")
        lineas.append(f"Lo más flojo que tengo: {stats['certeza_min']}")
        return "\n".join(lineas)

    def limite(self) -> str:
        lim = self.base.por_tema("meta/limites")
        if not lim:
            return f"Conocimiento curado hasta el {self.idn.corte}."
        return (f"Conocimiento curado hasta el {self.idn.corte}.\n\n"
                + lim[0].respuesta)


# ---------------------------------------------------------------------------
def conversacion(d: Docta, tripa: bool = False) -> None:
    print(d.quien())
    print("\nEscribe una pregunta. /quien /temas /limite /salir\n")
    print("─" * 66)

    while True:
        try:
            pregunta = input("\ntú › ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not pregunta:
            continue

        cmd = pregunta.lower()
        if cmd in ("/salir", "/quit", "salir", "adiós", "adios"):
            break
        if cmd in ("/quien", "/quién"):
            print(f"\n{NOMBRE} › {d.quien()}")
            continue
        if cmd == "/temas":
            print(f"\n{NOMBRE} › {d.temas()}")
            continue
        if cmd == "/limite":
            print(f"\n{NOMBRE} › {d.limite()}")
            continue

        print(f"\n{NOMBRE} › {d.responder(pregunta, tripa=tripa)}")

    print(f"\n{d.turnos} preguntas. Se acabó.")


def main() -> None:
    ap = argparse.ArgumentParser(
        description=f"{NOMBRE}: {__doc__}",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("-p", "--pregunta", action="append", default=None,
                    help="pregunta suelta (se puede repetir)")
    ap.add_argument("--quien", action="store_true", help="quién es y qué sabe")
    ap.add_argument("--temas", action="store_true", help="materias curadas")
    ap.add_argument("--limite", action="store_true", help="fecha de corte")
    ap.add_argument("--tripa", action="store_true",
                    help="enseña puntuaciones y candidatos internos")
    ap.add_argument("--umbral", type=float, default=0.15,
                    help="apoyo mínimo para atreverse a contestar")
    a = ap.parse_args()

    d = Docta(umbral_apoyo=a.umbral)

    if a.quien:
        print(d.quien()); return
    if a.temas:
        print(d.temas()); return
    if a.limite:
        print(d.limite()); return

    if a.pregunta:
        for q in a.pregunta:
            print(f"tú › {q}")
            print(f"{NOMBRE} › {d.responder(q, tripa=a.tripa)}")
            print()
        return

    conversacion(d, tripa=a.tripa)


if __name__ == "__main__":
    main()
